# -*- coding: utf-8 -*-

from . import models
from . import penilaian_kepala_sekolah
from . import penilaian_teman_sejawat
from . import penilaian_wali_murit
from . import penilaian_peserta_didik
from . import nilai_total